package objects;

import java.util.List;

//inherits from GeneralAssignment class
public class Deliverable extends GeneralAssignment{
	
	
}
