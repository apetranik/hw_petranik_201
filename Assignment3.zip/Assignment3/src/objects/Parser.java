package objects;


import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Scanner;

import javax.servlet.jsp.PageContext;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonSyntaxException;

public class Parser {
	public Parser() {
		
	}
	public static DataContainer parser(InputStream inputFile) {
		try {
			//Use GSON to parse
			InputStreamReader ir = new InputStreamReader(inputFile);
			
			Gson gson = new Gson();
			DataContainer as = gson.fromJson(ir, DataContainer.class);
			return as;
	
		}
		
		catch(JsonSyntaxException j) {
			System.out.println("Json Syntax Exception: " + j.getMessage());
		}
		//If there was an exception, return empty school
		DataContainer test = new DataContainer();
		return test;
	}
	
	
	
}
