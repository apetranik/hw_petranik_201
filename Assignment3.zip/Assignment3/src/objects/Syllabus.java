package objects;

public class Syllabus {
	private String url;

	public String getUrl() {
		return url;
	}
}
