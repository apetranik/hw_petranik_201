package parsing;
import objects.*;
import java.util.*;

public class TitleComparatorA implements Comparator<Assignment>{
	private int order;
	public TitleComparatorA(int x) {
		this.order = x;
	}
	 public int compare(Assignment a, Assignment b)
    {
		int result;
		if(a.getTitle() != null && b.getTitle() != null) {
			if(a.getTitle().compareTo(b.getTitle()) < 0) {
	        	result = -1;
	        }
			 else if(a.getTitle().compareTo(b.getTitle()) > 0){
	        	result = 1;
	        }
	        else {
	        	result = 0;
	        }			
		}
		else {
			result = 0;
		}
		if(order == 0) {
        	return result;
        }
        else {
        	return result*-1;
        }
    }
}
