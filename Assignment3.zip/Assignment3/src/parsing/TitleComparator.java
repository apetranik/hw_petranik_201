package parsing;
import objects.*;
import java.util.*;

public class TitleComparator implements Comparator<Deliverable>{
	private int order;
	public TitleComparator(int x) {
		this.order = x;
	}
	 public int compare(Deliverable a, Deliverable b)
    {
		int result;
        if(a.getTitle().compareTo(b.getTitle()) < 0) {
        	result = -1;
        }
        else if(a.getTitle().compareTo(b.getTitle()) > 0){
        	result = 1;
        }
        else {
        	result = 0;
        }
        if(order == 0) {
        	return result;
        }
        else {
        	return result*-1;
        }
    }
}
