package parsing;
import objects.*;
import java.util.*;

public class PercentComparatorA implements Comparator<Assignment>{
	private int order;
	public PercentComparatorA(int x) {
		this.order = x;
	}
	 public int compare(Assignment a, Assignment b)
    {
		int result;
		double aPercent = Double.parseDouble(a.getGradePercentage().substring(0, a.getGradePercentage().length() - 1));
		double bPercent = Double.parseDouble(b.getGradePercentage().substring(0, b.getGradePercentage().length() - 1));
		if(aPercent < bPercent) {
			result = -1;
		}
		else if(bPercent < aPercent){
			result = 1;
		}
		else {
			result = 0;
		}
		if(order == 0) {
        	return result;
        }
        else {
        	return result*-1;
        }
    }
}
