package parsing;
import objects.*;
import java.util.*;

public class DueDateComparatorA implements Comparator<Assignment>{
	private int order;
	public DueDateComparatorA(int x) {
		this.order = x;
	}
	 public int compare(Assignment a, Assignment b)
    {
		int result;
		String[] aDate = a.getDueDate().split("-");
		String [] bDate = b.getDueDate().split("-");
		
		if(Integer.parseInt(aDate[2]) < Integer.parseInt(bDate[2])) {
			result = -1;
		}
		else if(Integer.parseInt(aDate[2]) > Integer.parseInt(bDate[2])) {
			result = 1;
		}
		
		else if(Integer.parseInt(aDate[0]) < Integer.parseInt(bDate[0])) {
			result = -1;
		}
		else if(Integer.parseInt(aDate[0]) > Integer.parseInt(bDate[0])) {
			result = 1;
		}
		
		else if(Integer.parseInt(aDate[1]) < Integer.parseInt(bDate[1])) {
			result = -1;
		}
		else if(Integer.parseInt(aDate[1]) > Integer.parseInt(bDate[1])) {
			result = 1;
		}
		
		else {
			result = 0;
		}
		if(order == 0) {
        	return result;
        }
        else {
        	return result*-1;
        }
    }
}