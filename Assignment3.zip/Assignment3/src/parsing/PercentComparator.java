package parsing;
import objects.*;
import java.util.*;

public class PercentComparator implements Comparator<Deliverable>{
	private int order;
	public PercentComparator(int x) {
		this.order = x;
	}
	 public int compare(Deliverable a, Deliverable b)
    {
		int result;
		double aPercent = Double.parseDouble(a.getGradePercentage().substring(0,2));
		double bPercent = Double.parseDouble(b.getGradePercentage().substring(0, 2));
		if(aPercent < bPercent) {
			result = -1;
		}
		else if(bPercent < aPercent){
			result = 1;
		}
		else {
			result = 0;
		}
		if(order == 0) {
        	return result;
        }
        else {
        	return result*-1;
        }
    }
}
