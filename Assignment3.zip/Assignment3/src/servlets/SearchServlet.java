package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import objects.*;
/**
 * Servlet implementation class SearchServlet
 */
@WebServlet("/SearchServlet")
public class SearchServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {		
		DataContainer as = (DataContainer) request.getSession().getAttribute("allSchool");
	    Course c = as.getSchools().get(0).getDepartments().get(0).getCourses().get(0);
	    List<StaffMember> staffMembers = c.getStaffMembers();
		String searchName = request.getParameter("search").toLowerCase();
		System.out.println(searchName);	
		//ArrayList<Integer> ids = new ArrayList<Integer>();
		StringBuilder ids = new StringBuilder();
		PrintWriter pw = response.getWriter();
		for(int i = 0; i < staffMembers.size(); i++) {
			if(staffMembers.get(i).getName().getFirstName().toLowerCase().equals(searchName)) {
				ids.append(staffMembers.get(i).getID()+",");
			}
			else if(staffMembers.get(i).getName().getLastName().toLowerCase().equals(searchName)) {
				ids.append(staffMembers.get(i).getID()+",");
			}
			else{
				String name = staffMembers.get(i).getName().getFirstName().toLowerCase() + " " + staffMembers.get(i).getName().getLastName().toLowerCase();
				if(name.equals(searchName)) {
					ids.append(staffMembers.get(i).getID()+",");
				}
			}
		}
		String result = ids.toString();
		pw.println(result);
		pw.flush();
//		String json = new Gson().toJson(ids);
//	    response.setContentType("application/json");
//	    response.setCharacterEncoding("UTF-8");
//	    response.getWriter().write(json);
		    
	}

}
