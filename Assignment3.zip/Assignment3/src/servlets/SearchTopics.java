package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import objects.*;

/**
 * Servlet implementation class SearchTopics
 */
@WebServlet("/SearchTopics")
public class SearchTopics extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String keyword = request.getParameter("search").toLowerCase().trim();
		
		StringBuilder ids = new StringBuilder();
		PrintWriter pw = response.getWriter();
		
		DataContainer as = (DataContainer) request.getSession().getAttribute("allSchool");
	    Course c = as.getSchools().get(0).getDepartments().get(0).getCourses().get(0);
	    List<Week> weeks = c.getSchedule().getWeeks();
	    for(int i = 0; i < weeks.size(); i++){
	    	List<Lecture> lecs = weeks.get(i).getLectures();
	    	for(int j = 0; j < lecs.size(); j++){
	    		List<Topic> topics = lecs.get(j).getTopics();
	    		for(int k = 0; k < topics.size(); k++){
	    			String topTitle = topics.get(k).getTitle().toLowerCase();	
	    			int substring = topics.get(k).getTitle().toLowerCase().indexOf(keyword);
	    			if(topTitle.equals(keyword) || substring != -1) {
	    				ids.append(topics.get(k).getTitle()+",");
	    				System.out.println("keyword: " + keyword);
	    				System.out.println("title: " + topics.get(k).getTitle().toLowerCase());
	    				System.out.println("ids: " + ids.toString());
	    			}
	    		}
	    	}
	    }
	    String result = ids.toString();
		pw.println(result);
		pw.flush();
	}

}
