package servlets;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.nio.file.Paths;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import com.google.gson.JsonSyntaxException;

import objects.*;
import parsing.*;


@WebServlet("/ChooseFile")
@MultipartConfig
public class ChooseFile extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		// Get the json file
		Part filePart = request.getPart("filename");
		InputStream fileContent = filePart.getInputStream();
		DataContainer as = Parser.parser(fileContent);
		
		String design = request.getParameter("design");
		//Create a session and set the container object as an attribute
		HttpSession session = request.getSession(true);
		session.setAttribute("allSchool", as);
		session.setAttribute("design", design);
		//session.setMaxInactiveInterval(60);
	
		response.sendRedirect("home.jsp");

	}

}
