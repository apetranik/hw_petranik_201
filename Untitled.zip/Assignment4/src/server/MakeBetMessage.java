package server;

public class MakeBetMessage extends Message {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1;
	private String currentBetUsername = "";
	private int currentChips;
	boolean myTurn = false;
	public MakeBetMessage(String currentBetUsername, boolean myTurn, int currentChips)
	{
		super("bet", "");
		this.currentBetUsername = currentBetUsername;
		this.currentChips = currentChips;
		if(myTurn) myTurn = true;
	}
	public MakeBetMessage()
	{
		
	}

	public String getBetUsername()
	{
		return currentBetUsername;
	}
	public int getChips()
	{
		return currentChips;
	}



}
