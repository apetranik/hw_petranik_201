package server;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class ServerThread extends Thread {
	// Input/ ouput objects
	private ObjectInputStream ois;
	private ObjectOutputStream oos;
	
	private Server server;
	private Game currentGame;
	private String username = "";
	private boolean isOwner = false;
	private Hand hand = null;
	private int currentNumChips = 500;

	// Constructor
	public ServerThread(Socket s, Server server)
	{
		try
		{
			// Set the input and output stream objects
			// Important to do OUTPUT first
			this.server = server;
						
			oos = new ObjectOutputStream(s.getOutputStream()); // send to socket's output stream so client can receive it
			ois = new ObjectInputStream(s.getInputStream()); // receive from socket input stream
			
			this.start();
		}
		catch (IOException ioe)
		{
			System.out.println("ioe in ServerThread constructor: " + ioe.getMessage());
		}
	}
	
	// SEND MESSAGE
	// generic send message. This gets called from the server
	// It is passed on to the client by writing an object of message type
	public void sendMessage(Message m)
	{
		try {
		
			oos.writeObject(m);
			oos.flush();

		}
		catch(IOException ioe)
		{
			System.out.println("ioe" + ioe.getMessage());
		}
	}
	
	// Used to set the current game of the server thread
	// Used to keep track of the game associated w/ the serverthread
	public void setCurrentGame(Game game, boolean owner)
	{

		this.currentGame = game;
		// if true, this thread is the owner of the game
	}
	
	public void alertNewPlayerAdded(String username)
	{
		Message m = new OwnerInfoMessage(username, currentGame.getAvailableSpace());
		
		try
		{
			oos.writeObject(m);
			oos.flush();
		}
		catch(IOException ioe)
		{
			System.out.println("ioe: " + ioe.getMessage());
		}
		
		
	}

	
	// Called if the client sends something out
	// This method is always listening
	public void run()
	{
		try {
			while(true)
			{ 
				// keep reading until we get something from the client
				// Cast to generic object type, then check specific objec types
				Object obj = (Object)ois.readObject();

				// only called if we have just added a player to the game and we need to update the server
				if(obj instanceof AddPlayer)
				{
					AddPlayer player = (AddPlayer)obj;
					// if the username is still available, set the serverthread's username to the requested name;
					if(server.checkAddPlayer(player, currentGame, this))
					{		

						// send it back to the client to save
						oos.writeObject(player);
						oos.flush();
					}			
				}
				else if(obj instanceof BeginMessage)
				{
					BeginMessage begin = (BeginMessage)obj;
					server.readyToBegin(currentGame, begin.getInitalBet(), begin.firstBetMade(), this);
				}
				
				// client has just made a bet
				// must alert all other threads
				else if(obj instanceof ReceiveBetMessage)
				{
					ReceiveBetMessage message = (ReceiveBetMessage)obj;
					updateChips(message.getBet()); // update num chips
					server.requestBet(currentGame, this, true, message); // tell the server about it
				}
				
				// setiing up new game, includes capacity info
				
				// called for all other general messages
				else if(obj instanceof Message)
				{
					Message m = (Message)obj;
					server.broadcast(m, this); 
				}
				
			}
		}
		
		catch(IOException ioe)
		{
			System.out.println("ioe in ServerThread.run(); " + ioe.getMessage());
		}
		catch (ClassNotFoundException cnfe) // bc ois is being downcast to ChatMessage - could throw this kine exception
		{
			System.out.println("cnfe: " + cnfe.getMessage());
		}
		
	}
	// Tells the other threads its time to start and has teh initial bet of the owner
	public void alertReadyToBegin(String username, int initalBet, boolean ready)
	{
		BeginMessage mess = new BeginMessage(username, initalBet, ready);
		try
		{
			oos.writeObject(mess);
			oos.flush();
		}
		catch(IOException ioe)
		{
			System.out.println("ioe " + ioe.getMessage());
		}
				
	}
	// Send to the server threads not making the beting
	public void aboutToBet(String username)
	{
		AlertBetMessage message = new AlertBetMessage(username);
		try
		{
	
			oos.writeObject(message);
			oos.flush();
		}
		catch(IOException ioe)
		{
			System.out.println("ioe " + ioe.getMessage());
		}
		
	}
	// Ask user to bet
	public void setUsername(String username)
	{
		this.username = username;
	}
	// getter methods for username and current game
	public String getUsername()
	{
		return username;
	}
	public Game getCurrentGame()
	{
		return currentGame;
	}
	// set the serverthreads hand
	public void setHand(Hand hand)
	{
		this.hand = hand;
	}
	public void updateChips(int bet)
	{
		currentNumChips -= bet;
	}
	// returns num of chips
	public int getChips()
	{
		return currentNumChips;
	}
	

}
