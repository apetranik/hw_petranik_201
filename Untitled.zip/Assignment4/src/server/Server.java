package server;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.Vector;

public class Server {
	// keeps track of all the serverthreads
	private Vector<ServerThread> serverThreads = null; // keeps track of all serverthreads 
	private static Map<Game, Vector<ServerThread>> playerMap = null; // keeps track of which serverthreads are associated with which games
	private static Map<String, Game> games = null; // connects the name of the game with the game object
	private static Dealer dealer = null;
	
	public Server()
	{
		Scanner sc = new Scanner(System.in);

		int portNum = 0;
		boolean gotPort = false;
		ServerSocket ss;
		// keep accepting ports until a valid one is given
		do
		{
			System.out.println("Please enter a port number");
			// Check if the input is a number
			if(sc.hasNextInt())
			{
				portNum = sc.nextInt();
				// make sure the port num is valid - in range. otherwise throw an exception
				try 
				{
					ss = new ServerSocket(portNum);
					serverThreads = new Vector<ServerThread>();
					gotPort = true;
					System.out.println("Sucessfully started the Black Jack Server on port " + portNum);
					
					// accept all the connections
					while(true)
					{
						Socket s = ss.accept();
						System.out.println("Accepted connection from " + s.getInetAddress());
						// Every client gets it's own ServerThread instance
						ServerThread st = new ServerThread(s, this);
						serverThreads.add(st);
						
					}
					
				}
				// the port number is invalid
				catch(IOException ioe)
				{
					System.out.println("Invalid Port Number");
					continue;
				}
	
			}
			// a non-int value was entered
			else
			{
				sc.nextLine();
	            System.out.println("Invalid Port Number");
			}
		}while(!gotPort);
		
		// Made it here then we have successfully started the server
		
		
	}
	// Comes from the owner, and tells the rest of the threads in the game the game is ready to begin
	public void readyToBegin(Game game, int initalBet, boolean ready, ServerThread st)
	{
		
		st.updateChips(initalBet);
		
		// alert all threads that are in the game that the game is gonna start
		for(int i = 0; i < playerMap.get(game).size(); i++)
		{
			// don't alert the owner
			// But alert everyone else the game is gonna begin and tell them the inital bet of the owner
			if(playerMap.get(game).get(i) != st)
			{
				if(!ready) playerMap.get(game).get(i).alertReadyToBegin(st.getUsername(), initalBet, false);
				else playerMap.get(game).get(i).alertReadyToBegin(st.getUsername(), initalBet, true);
				
			}
			
		}
		// if not all players ready, return 
		if(!ready) return;
		
		// get all bets from the players so we can start the game
		getBets(game, st, false);
		

	}
	// get's everyone but the owner's inital bets
	public void getBets(Game game, ServerThread st, boolean received)
	{
		
		for(int i = 0; i < (playerMap.get(game)).size(); i++)
		{
			if(playerMap.get(game).get(i) != st)
			{
				ServerThread bettingThread = playerMap.get(game).get(i);
				// tell everyone that bettingThread is about to bet
				bettingMessage(game, bettingThread);
				// request bets from everyone
				requestBet(game, bettingThread, false, new ReceiveBetMessage());
				
			}
			
		}
		
	}
	// Request a bet from teh server thread inputed
	// wait until it is received and then send a message out to the other threads and return true
	public void requestBet(Game game, ServerThread st, boolean received, ReceiveBetMessage m)
	{
		// we received a bet back from the requested thread
		// alert everyone about it
		if(received) 
		{
			
			betAlert(game, m.getBet(), st, true);
			game.betMade();
			if(game.allBetsMade()) deal(game);
			// if all bets are done for this round, deal
	
			
		}
		// we did not receive an answer of a bet back. so return false;
		else
		{
			makeBet(game, st);

		}
	
	}
	// Tell everyone except the current st that they are betting
	// Specialized method for the serverthread that is making the bett
	public void bettingMessage(Game game, ServerThread st)
	{
		
		for(int i = 0; i < (playerMap.get(game)).size(); i++)
		{
			// don't alert the owner
			// But alert everyone else the game is gonna begin and tell them the inital bet of the owner
			if(playerMap.get(game).get(i) != st)
			{

				playerMap.get(game).get(i).aboutToBet(st.getUsername());
			}
			
			
		}
		
	}
	// Alert everyone else the bet that was just made
	public void betAlert(Game game, int bet, ServerThread st, boolean received)
	{
		if(!received) return;
		//st.updateChips(bet);
		// alert all threads that are in the game that the game is gonna start
		for(int i = 0; i < (playerMap.get(game)).size(); i++)
		{
			// don't alert the owner
			// But alert everyone else the game is gonna begin and tell them the inital bet of the owner
			if(playerMap.get(game).get(i) != st)
			{

				playerMap.get(game).get(i).alertReadyToBegin(st.getUsername(), bet, true);
			}
			
			
				
		}
	}
	// Request a bet from the serverthread
	public void makeBet(Game game, ServerThread st)
	{
		MakeBetMessage message = new MakeBetMessage(st.getUsername(), true, st.getChips());
		st.sendMessage(message);
		
	}
	// Deals hands to all players in the game
	public void deal(Game game)
	{
		for(int i = 0; i < (playerMap.get(game)).size(); i++)
		{
			// deals out new hands to all serverthreads in the game
			Hand hand = dealer.getNewHand();
			game.addHand(playerMap.get(game).get(i), hand);
			// add dealer hand
		//	game.addHand(st, hand);
			playerMap.get(game).get(i).setHand(hand);
		}
		Hand dealerHand = dealer.getNewHand();
		game.addDealer(dealerHand);
		displayHand(game);
	}
	// Used to display hand to each player in the game
	// Writes out to all serverthread objects 
	public void displayHand(Game game)
	{
		HandDisplayMessage message = new HandDisplayMessage(game.getDealerHand(), game.getAllHands());
		for(int i = 0; i < (playerMap.get(game)).size(); i++)
		{
			// Get the hand from the map in each game class
			Hand hand = game.getHand(playerMap.get(game).get(i));
			// Send it back to the serverthread to be saved
			playerMap.get(game).get(i).setHand(hand);
			// Relay to client to display
			playerMap.get(game).get(i).sendMessage(message);
		}
	}
		
	// Main broadcast method used for sending messages to the serverthreads
	public void broadcast(Message cm, ServerThread st)
	{
		// iterate thru all server threads and send message to each of them
		//if(message != null)
		if(cm != null)
		{
			// This only happens during game setup
			// we are checking if the game the user inputed exists
			if(cm.getPrefix().equals("newGame") || cm.getPrefix().equals("joinGame"))
			{
				sendMatch(cm, st);
			}
			// Rest of method is for normal game play
			
			//System.out.println(cm.getUsername() + ": " + cm.getMessage());
			
			for(ServerThread thread : serverThreads)
			{
				if(thread != st) // make sure it's not the client that sent you the message
				{
					//thread.sendMessage(message); // in the serverthread class
					//thread.sendMessage(cm);
				}
			}
		}
	}
	
	// this is used during setup to check that the username the player is trying to select isn't already in use
	public boolean checkAddPlayer(AddPlayer player, Game game, ServerThread st)
	{
		Vector<ServerThread> currentPlayers = playerMap.get(game);
		for(int i = 0; i < currentPlayers.size(); i++)
		{
			// check if the username associated with each thread in the playermap matches the requested new username
			if(currentPlayers.get(i).getUsername().equals(player.getPrefix()))
			{
				return false;
			}
		}
		
		// the username wasn't found, which means it is still available, so it is good to go
		// So add it to the list
		//currentPlayers.add(st);
		st.setUsername(player.getPrefix());
		if(game.getOwner() != st)
		{
			game.getOwner().alertNewPlayerAdded(player.getPrefix());
		}
		//game.addPlayer(player);
		return true;

	}
	// adds a serverthread to the running list of server threads
	// helps keep track of who's playing

	// Used during game setup to check if game the user input to join or create already exists
	// Sends message of this back to client thru serverthread
	public void sendMatch(Message cm, ServerThread st)
	{
		Message newMessage = null;
		String potentialGame = cm.getMessage(); // game the user input
		boolean alreadyExists = false;
		Game game = null;
		// If the user wants to create a new game
		// Loop thru all games that exist and see if there is a match
		for(Map.Entry<String, Game> entry : games.entrySet())
		{
			// the game matches. send response back to client
			if(entry.getKey().equals(potentialGame) && games.get(potentialGame).getAvailableSpace() != 0)
			{
				System.out.println("hi");
				alreadyExists = true;
				
			}
		}
		// user wants to create a new gam
		if(cm.getPrefix().equals("newGame"))
		{
			// game already exists so the user will have to chose another game name
			if(alreadyExists) 
			{
				newMessage = new SetupMessage(1, false, "setupGame");
				
			}
			// game doesn't exist, create new one
			else
			{
				SetupMessage mess = (SetupMessage)cm;

				// Create a new game and put it in the games map
				game = new Game(potentialGame, st, mess.getCapacity());
				//game.addPlayer(st);
				games.put(potentialGame, game);
				// create a new vector that will hold all the players for this game
				// add the serverthread connected to the new player to the vector
				Vector<ServerThread> newPlayers = new Vector<ServerThread>();
				newPlayers.add(st);
				// add that game and player vector to the map that keeps track of the games and players associated with those games
				playerMap.put(game, newPlayers);
				// set owner of game
				//game.setOwner(st);
				// send back the message about succesfully creating a game to the client
				newMessage = new SetupMessage(1, true, "setupGame");
				st.setCurrentGame(game, true);
			}
		}
		// user wants to join a game
		else
		{
			// the game already exists, so the user can join it
			if(alreadyExists) 
			{
				
				newMessage = new SetupMessage(2, true, "setupGame");
				// get the current players vector for the game the user wants to join
				game = games.get(potentialGame);
				Vector<ServerThread> currentPlayers = playerMap.get(game);
				// add the current serverthread to the list of players in teh game
				currentPlayers.add(st);
				// add player to the list of serverthreads in the game
				game.addPlayer(st);
				
				st.setCurrentGame(game, false);
				System.out.println("adding here");
				
			}
			// the game doesn't exist so the user can't join it
			else
			{
				newMessage = new SetupMessage(2, false, "setupGame");
			}
		}
		st.sendMessage(newMessage);
		
		
	}
	public static void main(String [] args)
	{
		// Start of program!
		// Print out welcome and ask for input for port #
		games = new HashMap<String, Game>();
		playerMap = new HashMap<Game, Vector<ServerThread>>();
		//games.put("test", new Game("test"));
		System.out.println("Welcome to the Black Jack Server!");
		dealer = new Dealer();
		Server server = new Server();
		
		
		
		
	}
}
