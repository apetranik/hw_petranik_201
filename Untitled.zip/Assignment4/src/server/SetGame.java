package server;

public class SetGame extends Message {

	/**
	 * 
	 */
	Game game = null;
	boolean owner = false;
	private static final long serialVersionUID = 1;
	public SetGame(Game game, boolean owner)
	{
		super("setGame", "");
		this.game = game;
		if(owner) owner = true;
	}
	public Game getGame()
	{
		return game;
	}
	public boolean isOwner()
	{
		return owner;
	}

}
