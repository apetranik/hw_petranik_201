package server;

public class OwnerInfoMessage extends Message {
	/**
	 * 
	 */
	
	private static final long serialVersionUID = 1;
	int spaceLeft;
	public OwnerInfoMessage(String username, int spaceLeft)
	{
		super(username, "");
		this.spaceLeft = spaceLeft;
		
	}
	public OwnerInfoMessage()
	{
		
	}
	public int getAvailableSpace()
	{
		return spaceLeft;
	}
}
