package server;

public class AlertBetMessage extends Message {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1;

	public AlertBetMessage(String username)
	{
		super(username, "");
	}


}
