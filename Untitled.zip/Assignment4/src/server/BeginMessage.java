package server;

public class BeginMessage extends Message {

	/**
	 * 
	 */
	// Tells all the clients it's time to start the game
	// includes inital bet info
	private static final long serialVersionUID = 1;
	int initalBet;
	boolean firstBetMade = false;
	public BeginMessage(String username, int initalBet, boolean firstBetMade)
	{
		super(username, "");
		this.initalBet = initalBet;
		if(firstBetMade) this.firstBetMade = true;
	}
	public int getInitalBet()
	{
		return initalBet;
	}
	public boolean firstBetMade()
	{
		return firstBetMade;
	}
	

}
