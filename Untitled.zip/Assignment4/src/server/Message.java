package server;

import java.io.Serializable;

public class Message implements Serializable {
	public static final long serialVersionUID = 1;
	private String prefix = "";
	private String message = "";
	
	public Message(String prefix, String message)
	{
		this.prefix = prefix;
		this.message = message;
	}
	public Message()
	{
		
	}
	
	public String getPrefix()
	{
		return prefix;
	}
	
	public String getMessage()
	{
		return message;
	}

}
