package server;

public class Dealer {
	public Dealer()
	{
		
	}
	public void shuffle()
	{
		
	}
	public Hand getNewHand()
	{
		int firstCard = (int)Math.ceil(Math.random() * 13 + 1);
		int firstSuit = (int)Math.ceil(Math.random() * 4);
		
		int secondCard = (int)Math.ceil(Math.random() * 13 + 1);
		int secondSuit = (int)Math.ceil(Math.random() * 4);
		
		
		Hand hand = new Hand(firstCard, firstSuit, secondCard, secondSuit);
		return hand;
		
	}
}
