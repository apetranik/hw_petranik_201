package server;

public class PlayerAlertMessage extends Message{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1;

	public PlayerAlertMessage(String username)
	{
		super(username, "");
	}
}
