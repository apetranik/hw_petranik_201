package server;

public class ReceiveBetMessage extends Message{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1;
	private int bet = 0;
	public ReceiveBetMessage(int bet)
	{
		super("bet", "");
		this.bet = bet;
	}
	public ReceiveBetMessage()
	{
		
	}
	public int getBet()
	{
		return bet;
	}
}
