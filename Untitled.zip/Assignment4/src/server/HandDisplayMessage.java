package server;

import java.util.HashMap;
import java.util.Map;

// Used to display the hand of a player
public class HandDisplayMessage extends Message {

	/**
	 * 
	 */
	Map<String, Hand> hands = null;
	Hand dealerHand = null;
	private static final long serialVersionUID = 1;
	public HandDisplayMessage(Hand dealer, Map<String, Hand> hands)
	{
		super("display", "");
		this.dealerHand = dealer;
		this.hands = new HashMap<String, Hand>();
		
		this.hands = hands;
	}
	public Map<String, Hand> getHands()
	{
		return hands;
	}
	public Hand getDealerHand()
	{
		return dealerHand;
	}

}
