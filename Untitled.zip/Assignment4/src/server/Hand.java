package server;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;

// Object that represents a hand with a vector of cards
public class Hand implements Serializable{
	private static final long serialVersionUID = 1;
	private Map<Integer, String> cardsMap = null;
	private Map<Integer, String> suitsMap = null;
	private Vector<Card> cards = null;
	private Card card1 = null;
	private Card card2 = null;
	private int status = 0;
	public Hand(int firstNum, int firstSuit, int secondNum, int secondSuit)
	{
		// fill in cards map;
		fillCards();
		// Create cards and fill them

		String valueCard1 = cardsMap.get(firstNum);
		String suitCard1 = suitsMap.get(firstSuit);

		cards = new Vector<Card>();
		
		this.card1 = new Card(firstNum, valueCard1, firstSuit, suitCard1);
	
		
		String valueCard2 = cardsMap.get(secondNum);
		String suitCard2 = suitsMap.get(secondSuit);
		this.card2 = new Card(secondNum, valueCard2, secondSuit, suitCard2);
		
		
		cards.add(card1);
		cards.add(card2);
		
	}
	
	// Fills the cards and suits map with the string associated with a card number and suit
	public void fillCards()
	{
		cardsMap = new HashMap<Integer, String>();
		cardsMap.put(1, "ONE");
		cardsMap.put(2, "TWO");
		cardsMap.put(3, "THREE");
		cardsMap.put(4, "FOUR");
		cardsMap.put(5, "FIVE");
		cardsMap.put(6, "SIX");
		cardsMap.put(7, "SEVEN");
		cardsMap.put(8, "EIGHT");
		cardsMap.put(9, "NINE");
		cardsMap.put(10, "TEN");
		cardsMap.put(11, "JACK");
		cardsMap.put(12, "QUEEN");
		cardsMap.put(13, "KING");
		cardsMap.put(14, "ACE");

		suitsMap = new HashMap<Integer, String>();
		suitsMap.put(1, "CLUBS");
		suitsMap.put(2, "DIAMONDS");
		suitsMap.put(3, "HEARTS" );
		suitsMap.put(4, "SPADES" );
		
		
	}
	// sets the status by adding all teh values up

	public int getStatus()
	{
		for(int i = 0; i < cards.size(); i++)
		{
			status+=cards.get(i).getValue();
		}
		return status;
	}
	
	public void hit()
	{
		//setStatus();
		
	}
	// displays all cards
	public String displayCards()
	{
		String output = "";
		for(int i = 0; i < cards.size(); i++)
		{
			output+=cards.get(i).getCard();
			output+= " | ";
		}
		
		return output;
	}
	// disolays all but the first card
	public String displayDealerCards()
	{
		String output = "? | ";
		for(int i = 1; i < cards.size(); i++)
		{
			output+=cards.get(i).getCard();
			output+= " | ";
		}
		output+= "\n-----------------------\n";
		output+= "-----------------------";
		return output;
	}
	
}
