package server;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

// Game object keeps track of all game info
public class Game implements Serializable {
	private static final long serialVersionUID = 1;
	
	private String username = "";
	private ArrayList<ServerThread> players = null;
	private ServerThread owner = null;
	private boolean isFull = false;
	private int capacity = 0;
	private Map<ServerThread, Hand> hands = null;
	private Hand dealerHand = null;
	private int numBets = 0;
	
	
	public Game(String name, ServerThread st, int capacity)
	{
		this.username = name;
		this.owner = st;
		this.capacity = capacity;
		players = new ArrayList<ServerThread>();
		addPlayer(owner);
	}
	public void setOwner(ServerThread owner)
	{
		//this.owner = owner;
		
		//addPlayer(owner);
	}
	public void setCapacity(int cap)
	{
		this.capacity = cap;
	}
	public void addPlayer(ServerThread player)
	{
		
		players.add(player);
		
	}
	public boolean isFull()
	{
		if(players.size() >= capacity) return true;
		return false;
	}
	public int getAvailableSpace()
	{
		return capacity-players.size();
	}
	public ServerThread getOwner()
	{
		return owner;
	}
	public ArrayList<ServerThread> getPlayers()
	{
		return players;
	}
	public int getCapacity()
	{
		return capacity;
	}
	// used by the server/dealer to add a new hand to the game
	// each hand is associated with a serverthread
	public void addHand(ServerThread st, Hand hand)
	{
		System.out.println("add hand");
		if(hands == null)
		{
			hands = new HashMap<ServerThread, Hand>();
			
		}
		hands.put(st, hand);

	}
	// Each game has a designated dealer
	public void addDealer(Hand hand)
	{
		
		dealerHand = hand;
	}
	public Hand getHand(ServerThread st)
	{
		return hands.get(st);
	}
	// returns all hands in the game
	// returns a map with string = username of player and it's associated hand
	public Map<String, Hand> getAllHands()
	{
		Map<String, Hand> allHands = new HashMap<String, Hand>();
		// go thru all serverthreads and get their username and hand
		for(Map.Entry<ServerThread, Hand> entry : hands.entrySet())
		{
			System.out.println("one hand");
			allHands.put(entry.getKey().getUsername(), hands.get(entry.getKey()));
		}
		return allHands;
	}
	public Hand getDealerHand()
	{
		return dealerHand;
	}
	public void betMade()
	{
		numBets++;
	}
	public void resetBets()
	{
		numBets = 0;
	}
	// all teh bets were made for this round
	public boolean allBetsMade()
	{
		if(numBets == players.size()-1) return true;
		return false;
	}
}

