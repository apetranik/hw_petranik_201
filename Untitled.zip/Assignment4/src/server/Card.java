package server;

import java.io.Serializable;

public class Card implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1;
	private String stringValue;
	private String stringSuit;
	private int value;
	private int suit;
	public Card(int value, String stringValue, int suit, String stringSuit)
	{
		if(value >= 10) this.value = 10;
		if(value == 14) 
		{
			this.value = 1;
		}
			
			
		this.suit = suit;
		this.stringValue = stringValue;
		this.stringSuit = stringSuit;
	}
	public int getValue()
	{
		return value;
	}

	public String getStringValue()
	{
		return stringValue;
	}
	public int getSuit()
	{
		return suit;
	}
	public String getStringSuit()
	{
		return stringSuit;
	}
	public String getCard()
	{
		return stringValue + " of " + stringSuit;
	}
}
