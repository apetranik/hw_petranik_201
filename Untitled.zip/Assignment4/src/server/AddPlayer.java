package server;

// Used when adding a player to the game and we need to notify all teh other serverthreads of it
public class AddPlayer extends Message {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1;

	public AddPlayer(String username)
	{
		super(username, "");

		
	}


}
