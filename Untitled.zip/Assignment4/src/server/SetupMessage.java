package server;

import java.io.Serializable;

// this class is a specialized type message used just during setup
// it communicates the user's choice of 1 or 2 to start or join a game
// it also contains a bool valid which determines if the user was or wasn't able to start/join a game
// and it contains the name of the game they tried to join or create
public class SetupMessage extends Message {
	/**
	 * 
	 */
	//private static final long serialVersionUID = 1;
	String prefix = "";
	String message = "";
	int choice = 0;
	boolean valid = false;
	String type = " ";
	int capacity = 0;

	SetupMessage(int choice, boolean valid, String type)
	{
		super("setup", "");
		this.choice = choice;
		if(valid) this.valid = true;
		//this.game = game;
		this.type = type;
	
	}
	SetupMessage(String username, String message, int capacity)
	{
		super(username, message);
		this.capacity = capacity;
	
	}

	public SetupMessage()
	{
		super("setup", "");
	}
	
	int getChoice()
	{
		return choice;
	}
	boolean getValid()
	{
		return valid;
	}

	String getType()
	{
		return type;
	}
	int getCapacity()
	{
		return capacity;
	}
}
