package server;

public class PlayerMessage extends Message {
	private String username;
	private String message;

	public PlayerMessage(String username, String message)
	{
		super(username, "");
	}

}
