package server;

import java.io.BufferedReader;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Map;
import java.util.Scanner;
// extends THread so we can receive messages too
public class Client extends Thread {

	private ObjectOutputStream oos;
	private ObjectInputStream ois;
	
	private String username = "";
	private Socket s = null;
	private Game currentGame;	
	private int numPlayers = 0;
	private int myChoice = 0;
	// Constructor
	public Client(String hostname, int port) throws IOException
	{
		// try to make a connection using the ipaddress and port that the user provided
		// throw an exception back to the main method if it doesn't work.
		try {
			Socket s = new Socket(hostname, port);
			this.s = s;
			
			// Initialize our input/output objects for sending b/w client and serverthread
			// IMPORTANT that input stream is first!
			
			ois = new ObjectInputStream(s.getInputStream());
			oos = new ObjectOutputStream(s.getOutputStream());
			
			this.start();
			
			// Successfully made a connection
			// Now we can ask the client questions
			Scanner sc = new Scanner(System.in);
			boolean valid = false; // keeps track of whether the user has chosen a valid option 1 or 2
			boolean gameJoined = false;
			// get the user's input until it's valid
			
			while(!valid)
			{
				
				System.out.println("Please Chose from the options below");
				System.out.println("1) Start Game");
				System.out.println("2) Join Game");
				if(sc.hasNextInt())
				{
					int choice = sc.nextInt();
					
					// User wants to START A GAME
					if(choice == 1)
					{
						this.myChoice = choice;
						boolean players = false; // if the user has chosen a valid # of players
						// Get user input for # of players
						while(!players)
						{
							System.out.println("Please chose the number of players in the game (1-3)");
							if(sc.hasNextInt())
							{
								int numPlayers = sc.nextInt();
								// user has input a valid number of players
								if(numPlayers >= 1 && numPlayers <=3)
								{
									this.numPlayers = numPlayers;
									players = true;
									valid = true;

									// Now check if the game they requested is a real game
									checkNewGame(new SetupMessage(), false);
	
								}
								else System.out.println("Invalid number of players");
								
							}
							// user did not enter a number
							else System.out.println("Invalid input");
						}
						
					}
					// user wants to JOIN a game
					else if(choice == 2)
					{
						this.myChoice = choice;
						boolean validGame = false;
						// Continue to get user input until the name is valid
						checkJoinGame(new SetupMessage(), false);
						
						valid = true;
					}
					// not a valid choice
					else
					{
						System.out.println("Invalid Input");
					}

				}
				else System.out.println("Invalid Input");
			}
			
			
			// Listening for client input
			/*while(true) {
				String line = sc.nextLine();
				// if the user has yet to join or start a game, we need to check for it
				
				Message cm = new Message(username, line);
				oos.writeObject(cm);
				oos.flush();
				
				
			}*/
		}
		catch(NullPointerException npe)
		{
			System.out.println("npe: " + npe.getMessage());
		}
		
	}
	
	// During game setup
	// Used to check the validaty of the game the user wants to join or create
	public void checkNewGame(SetupMessage cm, boolean received)
	{
		Scanner sc = new Scanner(System.in);
		// Only true if the run() method has been called, which means we have received a response back from the server	
		if(received)
		{
			// only true if the server response says the user can create or join the game they wanted to
			if(cm.getValid())
			{
				// set the current game to
				//this.currentGame = cm.getGame();
				pickUsername(cm.getChoice(), false);
			}
			else
			{
				System.out.println("Invalid choice. There is already an ongoing game with this name");

			}			
		}
			
		
		// User wants to create a new game
		if(cm.getValid()) return;	
		System.out.println("Please chose a name for your game");
		String gameName = sc.nextLine();
		Message message;
		
			
		message = new SetupMessage("newGame", gameName, numPlayers);
			
			// "newGame" tells the server to check for a game 
			// So the server doesn't treat it like a normal message
			// Will check for the game in the server
			// try to send the message to the server
			
		try
		{
			//open = true;
			oos.writeObject(message);
			oos.flush();
		}
		catch(IOException ioe)
		{
			System.out.println("ioe: " + ioe.getMessage());
		}
			
		
		// have received info back from client!
	
	}
	// During game setup
		// Used to check the validaty of the game the user wants to join or create
		public void checkJoinGame(SetupMessage cm, boolean received)
		{
			Scanner sc = new Scanner(System.in);
				
				if(received)
				{
			
					// Only move on if the game both exists and is accepting players still
					if(cm.getValid())
					{
	
						//this.currentGame = cm.getGame();
						pickUsername(cm.getChoice(), false);
					}
					// else the game doesn't exist or it is full. go back to step one and ask a game to join
					else
					{

						System.out.println("Invalid choice. There is no ongoing game awaiting players with this name");
					
					}

				}
				
				// User wants to create a new game
				if(cm.getValid()) return;
				// Continue to ask the player a game to join
				System.out.println("Please enter the name of the game you wish to join");
				String gameName = sc.nextLine();
				Message message;
				
				// "joinGame" tells the server to check for a game 
				// So the server doesn't treat it like a normal message
				// Will check for the game in the server
				message = new Message("joinGame", gameName);
				// try to send the message to the server
				
				try
				{

					oos.writeObject(message);
					oos.flush();
					
				}
				catch(IOException ioe)
				{
					
				}
						
			// have received info back from client!
		
		}
	
	// Used in game setup 
	// Deals with the user chosing a username
	
	public void pickUsername(int choice, boolean received) 
	{
		// TODO - u can chose whatever username u want lol
		
		if(received)
		{
			// the current client is the owner of the game so they created it
			if(choice == 1)
			{
				//game.setOwner(this);

				ownerStartGame(false, new OwnerInfoMessage());
				
			}
			// user wants to join a game, add them to the game
			else if(choice == 2)
			{
				
				//System.out.println("join");
				joinGame(true, false, "", 0, false);
			}
			
		}
		if(received) return;
		// Username wasn't accepted yet
		
		
			Scanner sc = new Scanner(System.in);
			System.out.println("Please pick a username");
			String name = sc.next();
			
			try
			{
				oos.writeObject(new AddPlayer(name));
				oos.flush();
			}
			catch(IOException ioe)
			{
				
			}
			//System.out.println("Invalid choice. There is no ongoing game awaiting players with this name");
		
		
		// User has finished picking a username
		
		
			
		
	
	}
	
	// this is used to start the game for the owner of the game
	// this client sees different messages than a general player
	// for instance they can see the number of players that still need to join and the usernames of the players who join
	public void ownerStartGame(boolean received, OwnerInfoMessage cm)
	{
		// this means this user is the owner of teh game and so should we a different message
		if(received)
		{
			System.out.println(cm.getPrefix() + " has joined the game");
			if(cm.getAvailableSpace() == 0)
			{
				System.out.println("Let the game commence. Good luck all players!");
				System.out.println("Dealer is shuffling...");
				System.out.println(username + ", it is your turn to make a bet. Your chip total is 500");
				Message m = new BeginMessage("begin", 0, false);
				try
				{
					oos.writeObject(m);
					oos.flush();
				}
				catch(IOException ioe)
				{
					
				}
				Scanner sc = new Scanner(System.in);
				int bet = sc.nextInt();
				System.out.println("You bet " + bet + " chips");
				m = new BeginMessage("begin", bet, true);
				try
				{
					oos.writeObject(m);
					oos.flush();
				}
				catch(IOException ioe)
				{
					
				}
				
			}
			else
			{
				System.out.println("Waiting for " + cm.getAvailableSpace() + " other players to join...");
			}
			
		}
		else
		{
			System.out.println("Waiting for " + (numPlayers - 1) + " other players to join...");
		}

	}

	public void joinGame(boolean received, boolean start, String username, int initalBet, boolean ready)
	{
		if(start && received && !ready)
		{
			System.out.println("Let the game commence. Good luck to all players!");
			
		}
		else if(start && received && ready)
		{
			System.out.println("Dealer is shuffling...");
			System.out.println(username + " bet " + initalBet + " chips");
		}
		else 
		{
			System.out.println("The game will commence shortly. Waiting for players to join...");
		}
	}
	// Tells the cilent which user is about to make a bet
	public void aboutToBetMessage(String username)
	{
		System.out.println("It is " + username + "'s turn to bet");
	}
	
	
	// called when the client receives a message from the server - relayed thru the serverthread
	public void run()
	{
		// try to read the object in
		try {
			while(true)
			{
				try 
				{
					//System.out.println("ok then");
					Object obj = (Object)ois.readObject();
					//System.out.println("back at it");
					if(obj instanceof SetupMessage)
					{

						SetupMessage cm = (SetupMessage)obj;
						if(cm.getType().equals("setupGame") && cm.getChoice() == 1)
						{
							checkNewGame(cm, true);	
						}
						if(cm.getType().equals("setupGame") && cm.getChoice() == 2)
						{
							checkJoinGame(cm, true);	
						}
						if(cm.getType().equals("setupUsername"))
						{
							
						}
					}
					// if this is triggered, it means that the username of the player was just accepted
					// So we should set the username that was requested to the username of this client
					else if (obj instanceof AddPlayer)
					{
						AddPlayer player = (AddPlayer)obj;
						this.username = player.getPrefix();
						pickUsername(myChoice, true);
						
					}
					
					// if game creation or joining was successful, set the currentgame to the game
					
					// if alerting of a new player joining the game
					// only for game owner
					else if (obj instanceof OwnerInfoMessage)
					{
		
						// tell the owner of teh thread a new player join
						OwnerInfoMessage m = (OwnerInfoMessage)obj;
						ownerStartGame(true, m);
						
						
					}
					
					// if the game is gonna begin, alert the threads
					else if (obj instanceof BeginMessage)
					{
						System.out.println("begin?");
						BeginMessage begin = (BeginMessage)obj;
						joinGame(true, true, begin.getPrefix(), begin.getInitalBet(), begin.firstBetMade());
					}
					// client needs to be alerting who is about to bet
					else if(obj instanceof AlertBetMessage)
					{
						AlertBetMessage message = (AlertBetMessage)obj;
						aboutToBetMessage(message.getPrefix());
					}
					// client needs to make a bet
					else if(obj instanceof MakeBetMessage)
					{
						MakeBetMessage message = (MakeBetMessage)obj;
						makeBet(message.getBetUsername(), message.getChips());
						
					}
					// used to display the hand to the client
					else if(obj instanceof HandDisplayMessage)
					{
						HandDisplayMessage handDisplay = (HandDisplayMessage)obj;
						printHands(handDisplay.getDealerHand(), handDisplay.getHands());
						
					}
					// Other generic messages
					else if (obj instanceof Message)
					{
						Message m = (Message)obj;
					}
					else
					{
					}
		
				}
				catch(IOException ioe)
				{
					System.out.println("Couldn't read object in client");
					continue;
				}
				

				//System.out.println(cm.getUsername() + ": " + cm.getMessage());
			}
		}
		
		catch( ClassNotFoundException cnfe)
		{
			System.out.println("cnfe: " + cnfe.getMessage());
		}
		catch(NullPointerException npe)
		{

		}
	}
	// Displays all the hands in the game to teh client
	public void printHands(Hand hand, Map<String, Hand> hands)
	{
		System.out.println("DEALER");
		System.out.print("Cards: | ");
		System.out.println(hand.displayDealerCards());
		for(Map.Entry<String, Hand> entry : hands.entrySet())
		{
			System.out.println("Player: " + entry.getKey() + "\n");
			System.out.println("Cards: | " + hands.get(entry.getKey()).displayCards());
			System.out.println("----------------------------------------");
			System.out.println("----------------------------------------");
		}
	}
	
	// Ask teh player to make a bet
	public void makeBet(String username, int currentChips)
	{
		System.out.println(username + " it is your turn to bet. You have " + currentChips + " chips");
		Scanner sc = new Scanner(System.in);
		int bet = sc.nextInt();
		ReceiveBetMessage newBet = new ReceiveBetMessage(bet);
		System.out.println("You bet " + bet + " chips");
		try
		{
			oos.writeObject(newBet);
			oos.flush();
		}
		catch(IOException ioe)
		{
			
		}
	}
	
	public static void main(String[] args)
	{
		// Start of client
		// Ask for 2 inputs, ipaddress and port of server
		boolean connectionMade = false;
		System.out.println("Welcome to Black Jack!");
		do
		{
			System.out.println("Please enter the ipaddress");
			Scanner sc = new Scanner(System.in);
			String ipaddress = sc.next();
			int port = 0;
			System.out.println("Please enter the port");
			// the port # was an integer. now we have to check if the combo can make a connection
			if(sc.hasNextInt())
			{
				try
				{
					port = sc.nextInt();
					Client cc = new Client(ipaddress, port);
					connectionMade = true;
				}
				// Unable to connect because port wasn't valid
				catch(IOException ioe)
				{
					System.out.println("Unable to connect to the server with provided fields");
					continue;
				}
			}
			else
			{
				System.out.println("Unable to connect to the server with provided fields");
			}
		}while(!connectionMade);
		
		
		
		
	}
}
