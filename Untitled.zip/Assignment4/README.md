Aliya Petranik
5784794365

The main server file is Server.java
The main client file is Client.java

Did not finish the betting
You can create multiple games and join but you can only do the initial betting stage
The program may also throw exceptions so you might have to restart it

Order the start:
Server - input "6789" for the port
Client - input "localhost" for ipaddress and then "6789" for port